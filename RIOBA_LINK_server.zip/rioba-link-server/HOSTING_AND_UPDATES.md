# Running RIOBA LINK: what goes where

## What the server is for
Only far-away mode. Two phones in different countries cannot find each other, so the server introduces them (5-digit code, host approval, connection details). After that the files go phone to phone and never touch it. Nearby and Same-Wi-Fi modes do not use it at all.

## What you host
- Backend: this server folder (Node). Host it on Render, Railway or Fly.io (about 0-7 USD a month to start). It must be HTTPS, one instance, TRUST_PROXY=1.
- Frontend: nothing. The app on the phone IS the frontend. It reaches users through Google Play (25 USD once) and the Apple App Store (99 USD a year).
- Relay (optional, recommended): some networks block direct phone-to-phone links. A TURN relay (Cloudflare Calls, env CF_TURN_KEY_ID / CF_TURN_API_TOKEN) fixes that. Relayed files pass through it and are billed per GB, so this is the cost that grows with use.

## Controlling the app after release
Change env vars on the host (no app update): MIN_APP_VERSION (force old apps to update), LATEST_APP_VERSION, FAR_AWAY_ENABLED=0 (switch far-away off in an emergency), NOTICE (message to users). The app reads GET /api/config.
Watch it: free uptime monitor (UptimeRobot) on /api/_healthcheck, and the host's logs.

## Making updates
- Server changes: edit, push to GitHub, the host redeploys by itself in about a minute. Keep old endpoints working until MIN_APP_VERSION passes the old apps.
- App changes: build a new version (raise versionCode), upload to Play Console (internal test -> production) or App Store Connect (TestFlight -> review, about 1-2 days). Users get it from the store.
- Always: test with a few phones first, release to 10% of users, then everyone.

## Monitoring (set up once)
1. UptimeRobot (free): new monitor, type HTTP(s), URL `https://YOUR-SERVER/api/_healthcheck`, every 5 minutes, add your email. You get an email when the server stops answering.
2. The health page also shows uptimeSeconds (a small number = it just restarted), liveRooms, requests, errors and roomsCreated.
3. Logs: in Render open your service > Logs. The server writes one JSON line for every server error (5xx) and every blocked request (429); wrong-code floods show up as many 429 lines.
## Changing the remote settings
Render > your service > Environment: MIN_APP_VERSION, LATEST_APP_VERSION, FAR_AWAY_ENABLED (0 = off), NOTICE. Save and the app picks it up the next time it opens. App version numbers are the versionCode in app/build.gradle.kts (first release = 1).
