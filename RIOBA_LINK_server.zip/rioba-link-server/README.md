# RIOBA LINK server (yours, not AppDeploy)

Tiny Node server (no dependencies). It only introduces devices for far-away mode: 5-digit code, host approval, WebRTC signals. Files never pass through it.

Run: `node server.js` (PORT env, default 8080). Test: open `/api/_healthcheck`.
Optional env for far-away transfers through strict networks: `CF_TURN_KEY_ID`, `CF_TURN_API_TOKEN` (Cloudflare Calls TURN).

Deploy free/cheap (any one): Render or Railway ("New Web Service" from this folder, start command `node server.js`), Fly.io (`fly launch`, uses the Dockerfile), or any VPS with `docker build -t rl . && docker run -d -p 80:8080 rl`.
Put it behind HTTPS (Render/Railway/Fly do this for you) and set env `TRUST_PROXY=1` so rate limits use each phone's real address. Sessions live in memory: run ONE instance.

Then build the app with your URL: `./gradlew assembleDebug -PserverUrl=https://your-server.example.com`
